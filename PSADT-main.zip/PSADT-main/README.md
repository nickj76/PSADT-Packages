# PSADT 
Repository to maintain Powershell App Deployment Toolkit deployment scripts. Some directories are referencing "evergreen", where this is set, this means that the all software files are dynamic and the latest version of installers are downloaded at the time of execution.
