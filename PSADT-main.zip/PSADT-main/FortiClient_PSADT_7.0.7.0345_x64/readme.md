# Commands.txt

Use commands.txt file to view installation, uninstallation and detection methods.

# VPN Profile

Ensure that you edit lines 161+ to match your VPN profile requirements in the Deploy-Application.ps1 script.

# Updating

If updating FortiClient to a later version for what is currently present, make sure to update the contents of the ps1 script, in particular the registation window registry keys and the detection method via SCCM \ Intune to match the version you are deploying.
