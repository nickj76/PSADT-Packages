# PSADT_Template 3.10.2

PSADT Template for use when packaging applications, scripts etc.

When updating please make sure to do the following.

Copy the below to the AppDeployToolkit folder 


AppDeployToolkitBanner.png

AppDeployToolkitLogo.ico

AppDeployToolkitLogo.png


Edit AppdeployToolkitConfig.xml to set show ballon notifications to "False"

Copy "place_installation_files_here.txt" text file to \Files folder 

Copy "place_support_files_here.txt" text file to \SupportFiles folder

Copy the following from the root of the old template to the root of the new template


README.md

ServiceUI.exe

Cmds.txt


# Notes

if you want to add the autocomplete options to vscode make sure to launch vscode as admin the open and run AppDeployToolkitMain.ps1 (you will need to do this each time you open vscode).